#!/usr/bin/env python
# encoding: utf-8

class Dynamic(str):
    """Wrapper for the strings that need to be dynamically interpreted by the generated Python files."""
    pass
#!/usr/bin/env python
# encoding: utf-8

from mocodo.__main__ import main

if __name__ == "__main__":
    main()
